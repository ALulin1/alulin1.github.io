Chao Li - Curriculum vitae source
Updated: 8 October 2026
Main file: cv-llt.tex
Use XeLaTeX and Biber. The project requires CurVe and biblatex.
Upload the project to Overleaf or compile with a complete TeX distribution.
